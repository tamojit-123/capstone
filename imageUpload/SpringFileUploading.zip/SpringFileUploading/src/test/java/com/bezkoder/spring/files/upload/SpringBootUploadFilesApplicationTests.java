package com.bezkoder.spring.files.upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUploadFilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
